﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Steganography
{
    public partial class FormMain : Form
    {
        public FormMain()
        {
            InitializeComponent();
        }

        private void embeddLargeMessageToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmSteganography frm = new FrmSteganography();
            frm.Show();
        }

        private void attachDocumentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmSteganography frm = new FrmSteganography();
            frm.Show();
        }

        private void userInputTextToolStripMenuItem_Click(object sender, EventArgs e)
        {
            TextStegano steg = new TextStegano();
            steg.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            TextStegano txt = new TextStegano();
            txt.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            FrmSteganography frm = new FrmSteganography();
            frm.Show();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
    }
}
